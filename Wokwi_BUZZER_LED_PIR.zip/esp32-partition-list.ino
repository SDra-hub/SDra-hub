int PIR = 27;
int LED = 26;

void setup() {
  pinMode(PIR, INPUT);
  pinMode(LED, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  int PIRValue = digitalRead(PIR);

  if (PIRValue == HIGH){
    digitalWrite(LED, HIGH);
    Serial.println("Pohyb detekovaný!");
    
  } else {
    digitalWrite(LED, LOW);
  }
  delay(1000);
}